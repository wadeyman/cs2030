class Done extends Event {
    private final int serverNum; 
    private static final int PRIOVALUE = 4;

    Done(double timeIn, Customer customer, int serverNum) {
        super(timeIn, 0, customer, PRIOVALUE);
        this.serverNum = serverNum;
    }

    public int getServerNum() { 
        return this.serverNum;
    }

    // the timein method inherited from Event in Done will 
    // call the timein constructor which i will put in timedone

    @Override
    public String stringify() {
        return String.format("%.3f %s done serving by %s", this.getTimeIn(), 
            this.getCust().getCustomerNum(), this.getServerNum());
    }
    
    @Override
    public Pair<Done, ImList<Server>> execute(ImList<Server> allServers, 
        int freeServerTag, int freeQServerTag) {
        return new Pair<>(this, allServers);
    }
}