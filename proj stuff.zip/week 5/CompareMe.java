import java.util.Comparator;

class CompareMe implements Comparator<Event> {
    /**
     * we first throw all events in. compare by TIME FIRST
     * then if same time
     * compare by CUSTOMER TAG
     * then if same customer num
     * compare by PRIORITY
     */

    @Override
    public int compare(Event a, Event b) {
        double diff = a.getTimeIn() - b.getTimeIn();
        if (diff < 0) {
            return -1;
        } else if (diff > 0) {
            return 1;
        } else if (diff == 0) {
            return compareCust(a, b);
        } else {
            return 0;
        }
    }
    
    public int compareCust(Event a, Event b) {
        double custDiff = a.getCust().getCustomerNum() - b.getCust().getCustomerNum();
        if (custDiff > 0) {
            return 1;
        } else if (custDiff < 0) {
            return -1;
        } else if (custDiff == 0) {
            return comparePrio(a, b);
        } else {
            return 0;
        }
    }

    public int comparePrio(Event a, Event b) {
        double prioDiff = a.getPrio() - b.getPrio();
        if (prioDiff < 0) {
            return -1;
        } else if (prioDiff > 0) {
            return 1;
        } else {
            return 0;
        }
    }
    
    // if compare event same time then look at priority
    // value
    // arrrive vs server vs done , let them extend events
    // simulator to return the string of events
}

