public class Leave extends Event {
    private static final int PRIOVALUE = 5;
    private static final double NODURATION = 0;
    
    Leave(double timeIn, Customer customer) {
        super(timeIn, NODURATION, customer, PRIOVALUE);
    }

    Leave() {
        super(0, NODURATION, new Customer(), PRIOVALUE);
    }

    @Override
    public String stringify() {
        return String.format("%s leaves", super.stringify());
    }
 
    @Override
    public Pair<Leave, ImList<Server>> 
        execute(ImList<Server> allServers, int freeServerTag, int freeQServerTag) {
        return new Pair<>(this, allServers);
    }
    
}
