import java.util.function.Supplier;

class DefaultServiceTime implements Supplier<Double> {
    private static final double DFS = 1.0;
    // depending on future implementation, service times can differ

    public Double get() {
        System.out.println("generating service time...");
        return generateServiceTime();
    }

    public Double generateServiceTime() {
        return DFS;
    }
}
