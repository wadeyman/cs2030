import java.util.function.Supplier;

class Simulator extends CompareMe {
    private final int numOfServers;
    private final int qMax;
    private final ImList<Double> arrivalTimes;
    private final Supplier<Double> serviceTimes;

    public Simulator(int numOfServers, int qMax, 
        ImList<Double> arrivalTimes, Supplier<Double> serviceTimes) {
        this.numOfServers = numOfServers;
        this.qMax = qMax;
        this.arrivalTimes = arrivalTimes;
        this.serviceTimes = serviceTimes;
    }

    private int getServerSize() {
        return this.numOfServers;
    }

    private int getQsize() {
        return this.qMax;
    }

    public int getCustomerSize() {
        return this.getArrTimes().size();
    }

    public ImList<Double> getArrTimes() {
        return this.arrivalTimes;
    }

    public Supplier<Double> getSerTimes() {
        return this.serviceTimes;
        // will call to Supplier class, so need to use Supplier.get
    }   

    // need to decide prio values for Arrive, Wait/ Serve, Done, Leave
    public PQ<Event> makeArrivePq() {
        PQ<Event> arrivePq = new PQ<>(new CompareMe()); 
        // my overridden compare function from CompareMe class

        for (int i = 1; i <= this.getCustomerSize(); i++) {
            Customer newDude = 
                new Customer(this.getArrTimes().get(i - 1), this.getSerTimes(), i); 
            // has a Supplier object (DONT CALL UNNECCESARILY), 
            // placeholder server == -1 thats not serving
            // customer num and STOREDUR = 0
            // newly created ARRIVE event has
            // double UNREALISTICDURATION = -1.0;
            arrivePq = arrivePq.add(new Arrive(newDude.getArriveT(), newDude));
        }
        return arrivePq;
    } // ok

    // create list of all shop servers, all are free at first
    public ImList<Server> genServers() {
        ImList<Server> holder = new ImList<Server>();
        for (int i = 0; i < this.getServerSize(); i++) {
            Server servHolder = new Server(i + 1);
            holder = holder.add(servHolder);
        }    
        return holder;
    } // has numtag, 0 time start, 0 duration, 0 qdurations, 0cust queueing
    // ok

    public int firstFreeServerTag(ImList<Server> allServers, 
        double currTime) { 
        // check first server that is not serving anyone,
        // no timein and no duration
        int keep = 0;
        for (int i = 0; i < allServers.size(); i++) { 
            if (allServers.get(i).getTimeIn() == 0) {
                keep = allServers.get(i).getTag();
                i = allServers.size() + 1;
            } else {
                keep = 0; // means no server is free
            }
        }
        return keep;
    } 

    public int freeQServerTag(ImList<Server> allServers) {
        int keep = 0;
        // for each server, check whether their imlist queue
        // is at max capacity, if not full
        // return first server tag with not full queue
        for (int i = 0; i < allServers.size(); i++) {
            if (allServers.get(i).getQueue().size() < this.getQsize()) {
                keep = allServers.get(i).getTag();
                i = allServers.size() + 1;
            } else {
                keep = 0; // means no queue is free
            }
        }
        return keep;
    } 
    
    public ImList<Server> shoveq(ImList<Server> allServers, 
        double currTime) {
        for (int i = 0; i < allServers.size(); i++) {
            if (allServers.get(i).getTimeDone() == currTime 
                && allServers.get(i).getQueue().size() > 0) {
                Server upd8 = allServers.get(i).moveQueue(currTime);
                allServers = allServers.set(i, upd8);
            } else if (allServers.get(i).getTimeDone() == currTime && 
                allServers.get(i).getQueue().size() == 0) {
                Server upd9 = new Server(allServers.get(i).getTag());
                allServers = allServers.set(i, upd9);
            }
        }
        return allServers;
    }

    public String simulate() {
        PQ<Event> testPq = this.makeArrivePq();
        ImList<Server> allServers = this.genServers();
        // has all the events it needs,
        // then the PQ black box sorts evrything by comparator compare method
        String simStr = "";
        
        double totalWaitTime = 0.0;
        int served = 0;
        int left = 0;

        while (testPq.isEmpty() != true) { 
            Pair<Event, PQ<Event>> pairHold = testPq.poll();
            System.out.println(pairHold.first());
            double currTime = pairHold.first().getTimeIn();
            allServers = this.shoveq(allServers, currTime);
            int freeServerTag = this.firstFreeServerTag(allServers, currTime);
            int freeQServerTag = this.freeQServerTag(allServers);
            Pair<? extends Event, ImList<Server>> executeEvent = 
                pairHold.first().execute(allServers, freeServerTag, freeQServerTag);
            // [[event, Allserver], string] pair of pair
            allServers = executeEvent.second();
            String firstLine = pairHold.first().stringify();
            if (firstLine.contains("leaves")) {
                left = left + 1;
            }
            if (firstLine.contains("serves")) {
                served = served + 1;
                totalWaitTime = totalWaitTime + 
                    (pairHold.first().getTimeIn() - 
                    pairHold.first().getCust().getArriveT());
            }
            
            simStr = simStr + firstLine + "\n";
            
            if (pairHold.first().equals(executeEvent.first()) == false) {
                testPq = pairHold.second().add(executeEvent.first());

            }  else {
                for (int i = 0; i < allServers.size(); i++) {
                    if (allServers.get(i).getTimeDone() == currTime &&
                    allServers.get(i).getQueue().size() > 0) {
                        Serve serveNext = new Serve(currTime, 
                        allServers.get(i).nextCust(), i + 1);
                        testPq = pairHold.second().add(serveNext);
                    } else if (allServers.get(i).getTimeDone() == currTime && 
                    allServers.get(i).getQueue().size() == 0) {
                        Server renew = new Server(i + 1);
                        allServers = allServers.set(i, renew);
                        testPq = pairHold.second();
                    } else {
                        testPq = pairHold.second();
                    }
                    System.out.println(allServers);
                    System.out.println(testPq);
                }
            }
        }
        double avgwaitTime = totalWaitTime / served;
        return simStr + String.format("[%.3f %s %s]",
            avgwaitTime, served, left); 
    }

}
