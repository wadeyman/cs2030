
class Event {
    
    private final double timeIn;
    private final double duration;
    private final Customer customer;
    private final int prioValue;

    // event to take in Customer class

    Event(double timeIn, double duration, Customer customer, int prioValue) {
        this.timeIn = timeIn;
        // be clear that this is always the time START of this event
        this.duration = duration;
        this.customer = customer;
        this.prioValue = prioValue;
    }

    Event() {
        this.timeIn = 0;
        this.duration = 0;
        this.customer = new Customer();
        this.prioValue = 0;
    }

    public Customer getCust() {
        return this.customer;
    }

    public double getTimeIn() {
        return this.timeIn;
    }

    public double getDuration() {
        return this.duration;
    }

    public double getTimeDone() {
        return this.getTimeIn() + this.getDuration();
    }

    public int getPrio() {
        return this.prioValue;
    }

    public String stringify() {
        String toReturn = String.format("%.3f %s", 
            this.getTimeIn(), this.getCust().getCustomerNum());
        return toReturn;
    }

    public Pair<? extends Event, ImList<Server>>
        execute(ImList<Server> allServers, int freeServerTag, int freeQServerTag) { 
        // execute the event by return a time and a person num
        
        Event placeEvent = new Event();
        ImList<Server> placeServer = new ImList<Server>();
        Pair<Event, ImList<Server>> placePair = 
            new Pair<>(placeEvent, placeServer); 
        return placePair;
        // list [event, server, string] in 0,1,2
    }

}
