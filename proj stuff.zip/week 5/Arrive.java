class Arrive extends Event {
    private static final int PRIOVALUE = 1;
    private static final double UNREALISTICDURATION = -1.0;

    Arrive(double timeIn, double duration, Customer customer) {
        super(timeIn, duration, customer, PRIOVALUE); // put arrive prio 1 first
    }

    Arrive(double timeIn, Customer customer) {
        super(timeIn, UNREALISTICDURATION, customer, PRIOVALUE);
    }

    @Override
    public String stringify() {
        return super.stringify() + " arrives";
    }
    
    @Override
    public Pair<? extends Event, ImList<Server>> execute(ImList<Server> allServers, 
        int freeServerTag, int freeQServerTag) {
        Customer thisCust = this.getCust();
        double thisCustTimeIn = this.getCust().getArriveT();
        
           
        if (freeServerTag != 0) {
            Serve toServe = new Serve(thisCustTimeIn, 
                this.getCust(), freeServerTag);
            Server server = new Server(freeServerTag, thisCustTimeIn,
                0.0, new ImList<Customer>());
            allServers = allServers.set(freeServerTag - 1, server);
            Pair<Serve, ImList<Server>> needPair = new Pair<>(toServe, allServers);
            return needPair;
        } else if (freeServerTag == 0 && freeQServerTag != 0) {
            Server waitMan = 
                allServers.get(freeQServerTag - 1).queueNewcust(thisCust);
            allServers = allServers.set(freeQServerTag - 1, waitMan);
            Wait waits = new Wait(thisCustTimeIn, thisCust, freeQServerTag);
            Pair<Wait, ImList<Server>> need2Pair = new Pair<>(waits, allServers);
            return need2Pair;
        } else {
            Leave leaves = new Leave(thisCustTimeIn, thisCust);
            Pair<Leave, ImList<Server>> need3Pair = new Pair<>(leaves, allServers);
            return need3Pair;
        }
        
    }

    
}
