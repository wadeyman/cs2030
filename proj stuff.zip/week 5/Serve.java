class Serve extends Event {
    private final int serverNum;
    private static final int PRIOVALUE = 2;
    private static final double NODUR = 0.0;

    Serve(double timeIn, Customer customer, int serverNum) {
        super(timeIn, NODUR, customer, PRIOVALUE);
        this.serverNum = serverNum;
    }

    @Override
    public String stringify() {
        return String.format("%.3f %s serves by %s", 
            this.getTimeIn(), this.getCust().getCustomerNum(), this.serverNum);
    }

    public Done makeDone() {
        Customer getsServed = this.getCust().supService(this.getCust().getServiceT());
        double timeDone = this.getTimeIn() + getsServed.getStoreDur();
        return new Done(timeDone, getsServed, this.serverNum);
    }

    @Override
    public Pair<Done, ImList<Server>> 
        execute(ImList<Server> allServers, int freeServerTag, int freeQServerTag) {
        Done makeDone = this.makeDone();
        Server serving = allServers.get(makeDone.getServerNum() - 1);
        Server upd8 = new Server(serving.getTag(), this.getTimeIn(),
            makeDone.getCust().getStoreDur() , serving.getQueue());
        allServers = allServers.set(serving.getTag() - 1, upd8);
        return new Pair<Done, ImList<Server>>(makeDone, allServers);
    } 

}