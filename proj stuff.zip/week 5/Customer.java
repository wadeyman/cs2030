import java.util.function.Supplier;


class Customer {
    // need to have service time in DEFAULTSERVICETIME class
    // include this into WAIT event
    // then generate WAIT events into entire PQ
    private final double timeIn;
    private final Supplier<Double> duration;
    private final int customerNum;
    private final int serverTag;
    private static final int PLACEHOLDER = -1;
    private final double storeDur;

    public Customer(double timeIn, 
        Supplier<Double> duration, int customerNum, int serverTag, double storeDur) {
        this.timeIn = timeIn;
        this.duration = duration;
        this.customerNum = customerNum;
        this.serverTag = serverTag;
        this.storeDur = storeDur;
    }

    public Customer(double timeIn, Supplier<Double> duration, int customerNum) {
        this.timeIn = timeIn;
        this.duration = duration;
        this.customerNum = customerNum;
        this.serverTag = PLACEHOLDER; 
        this.storeDur = 0.0;
    }

    public Customer() {
        this.timeIn = 0;
        this.duration = new DefaultServiceTime();
        this.customerNum = 0;
        this.serverTag = PLACEHOLDER; 
        this.storeDur = 0.0;
    }

    public double getArriveT() {
        return this.timeIn;
    }

    public double getServiceT() {
        return this.duration.get();
    } // when i call this i should store him
    // back into a new customer

    public Customer supService(double getServiceT) {
        return new Customer(this.timeIn, this.duration, 
            	this.customerNum, this.serverTag, getServiceT);
    }

    public double getStoreDur() {
        return this.storeDur;
    }

    public double getTimeDone() {
        return this.getArriveT() + this.getStoreDur();
    }

    public int getCustomerNum() {
        return this.customerNum;
    }

    public int getCustServerTag() {
        return this.serverTag;
    }

    public String toString() {
        return String.format("%s", this.getCustomerNum());
    }
}
