class Server {
    private final int serverTag;
    private final double timeIn;
    private final double duration;
    private final double timeDone;
    // save timeDone as timein + duration --> duration will 
    // take in value from a getservicetime called once
    private final ImList<Customer> queue; 
    // think about whether this should be IMLIST of customers queuing
    
    // servetag, current serve timein duration, 
    // list of next durations, list of customers in queue
    Server(int serverTag, double timeIn, 
        double duration, ImList<Customer> queue) {
        this.serverTag = serverTag;
        this.timeIn = timeIn;
        this.duration = duration;
        this.timeDone = timeIn + duration;
        this.queue = queue;
    }

    Server(int serverTag) {
        this.serverTag = serverTag;
        this.timeIn = 0; // current customer start
        this.duration = 0; // current customer time taken
        this.timeDone = timeIn + duration;
        this.queue = new ImList<Customer>();
    } // inital servers in allServers in shop has no time in/ duration
    // and an empty customer queue

    public int getTag() {
        return this.serverTag;
    }

    public double getTimeIn() {
        return this.timeIn;
    }

    public double getDuration() {
        return this.duration;
    }

    public double getTimeDone() {
        return this.timeDone;
    }

    public Customer nextCust() {
        return this.queue.get(0);
    }

    public double nextCustDuration() {
        return this.queue.get(0).getStoreDur();
    } // returns the double value duration not supplier

    public ImList<Customer> getQueue() {
        return this.queue;
    }
    
    public Server queueNewcust(Customer customer) {
        ImList<Customer> newQ = this.getQueue().add(customer); 
        return new Server(this.serverTag, this.timeIn, 
            this.duration, newQ);
    }

    public Server moveQueue(double currTime) {
        
        ImList<Customer> updateQcust = this.getQueue().remove(0);
        return new Server(this.serverTag, currTime, this.getDuration(), 
            updateQcust);
    }

    @Override
    public String toString() {
        return String.format("%s %s %s %s", 
            this.getTag(), this.getTimeIn(), this.getTimeDone(), this.getQueue());
    }
    

    // Main.java
    // Customer.java
    // Shop.java
}


