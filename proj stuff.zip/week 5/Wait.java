public class Wait extends Event {
    private final int serverNum; 
    private static final double PLACEHOLDERDURATION = 0;
    private static final int PRIOVALUE = 3; 
    // need to think of Priority assignment

    Wait(double timeIn, Customer customer, int serverNum) {
        super(timeIn, PLACEHOLDERDURATION, customer, PRIOVALUE);
        this.serverNum = serverNum;
    }
    
    // this is a wait event
    public int getQServer() {
        return this.serverNum;
    }

    @Override
    public String stringify() {
        return super.stringify() + String.format(" waits at %s", this.serverNum);
    }

    @Override
    public Pair<Wait, ImList<Server>> execute(ImList<Server> allServers, 
        int freeServerTag, int freeQServerTag) {
        return new Pair<>(this, allServers);
    }

}
